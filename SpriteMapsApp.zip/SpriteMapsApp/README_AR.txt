طريقة بناء الـ APK (تحتاج جهاز كمبيوتر + إنترنت مرة واحدة فقط للبناء):
1) ثبّت Android Studio (مجاني).
2) File > Open ثم اختر مجلد SpriteMapsApp وانتظر انتهاء Sync.
3) Build > Build Bundle(s) / APK(s) > Build APK(s).
4) ستجد الملف في: app/build/outputs/apk/debug/app-debug.apk
5) انقله للجوال وثبّته. التطبيق يعمل بدون نت، ولا يطلب صلاحية إنترنت أصلًا.
الملفات المصدّرة تُحفظ في: التنزيلات/SpriteMaps
